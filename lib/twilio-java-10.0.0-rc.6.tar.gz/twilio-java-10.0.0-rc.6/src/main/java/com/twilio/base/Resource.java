package com.twilio.base;

import java.io.Serializable;

public abstract class Resource implements Serializable {

    private static final long serialVersionUID = -5898012691404059595L;

}
